package Item;

public class ItemType {

}
